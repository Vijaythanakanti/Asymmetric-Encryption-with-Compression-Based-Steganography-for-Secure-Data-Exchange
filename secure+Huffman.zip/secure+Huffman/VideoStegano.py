import numpy as np
import cv2
from scipy import signal

# Define Reed-Solomon code parameters
n = 255  # length of codeword
k = 223  # length of message
t = 16  # error correction capability
g = signal.generator_matrix((n - k, t + 1))


# Define embedding function
def embed(msg, cover_video):
    # Convert message to binary string
    msg_bin = ''.join(format(ord(c), '08b') for c in msg)

    # Pad message to multiple of k bits
    msg_bin += '0' * (k - len(msg_bin) % k)

    # Split message into k-bit blocks
    msg_blocks = [msg_bin[i:i + k] for i in range(0, len(msg_bin), k)]

    # Encode message using Reed-Solomon code
    encoded_blocks = []
    for block in msg_blocks:
        data = np.array([int(bit) for bit in block])
        encoded = np.dot(data, g) % 2
        encoded_blocks.append(encoded.tolist())

    # Flatten video frames
    frames = cover_video.reshape((-1, 3))

    # Embed encoded blocks into LSB of blue channel
    for i, block in enumerate(encoded_blocks):
        for j, bit in enumerate(block):
            if bit == 0:
                frames[i * k + j, 2] &= ~1
            else:
                frames[i * k + j, 2] |= 1

    # Reshape frames to original shape
    stego_video = frames.reshape(cover_video.shape)

    return stego_video


# Define extraction function
def extract(stego_video):
    # Flatten video frames
    frames = stego_video.reshape((-1, 3))

    # Extract LSBs of blue channel
    msg_bits = []
    for i in range(0, len(frames), k):
        block = []
        for j in range(k):
            bit = frames[i + j, 2] & 1
            block.append(bit)
        msg_bits += block

    # Decode message using Reed-Solomon code
    msg_blocks = [msg_bits[i:i + n] for i in range(0, len(msg_bits), n)]
    decoded_blocks = []
    for block in msg_blocks:
        data = np.array(block)
        decoded = signal.decode_rs(data, n, k, gfpoly=0x11d, errs_pos=None)
        decoded_blocks.append(decoded.tolist())

    # Convert decoded blocks to message string
    msg_bin = ''.join([str(bit) for block in decoded_blocks for bit in block])
    msg = ''.join([chr(int(msg_bin[i:i + 8], 2)) for i in range(0, len(msg_bin), 8)])

    return msg
